﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acme.Common
{

    public static class Cliente
    {

		public static string Adios(string nombreCliente)
        {
            return "Hasta luego: " + nombreCliente;
        }

	}
}
