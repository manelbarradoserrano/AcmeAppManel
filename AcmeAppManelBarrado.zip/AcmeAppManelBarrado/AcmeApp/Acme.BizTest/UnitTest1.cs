using Acme.Common;
using Acme.Biz;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Acme.Common.Tests
{
    [TestClass()]
    public class UnitTest1
    {
        [TestMethod()]
        public void AdiosTest()
        {
            // Arrange
            var expected = "Hasta luego: Manel Barrado";

            // Act
            var actual = Cliente.Adios("Manel Barrado");

            // Assert
            Assert.AreEqual(expected, actual);
        }
    }
}

namespace Acme.Biz.Tests
{
    [TestClass()]
    public class UnitTest1
    {
        [TestMethod()]
        public void InfoProductoTest()
        {
            // Arrange
            var p1 = new Producto();
            p1.Id = 1;
            p1.Precio = 35;

            var expected = "El producto 1, tiene un precio de 35�";

            // Act
            var actual = p1.InfoProducto();

            // Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void InfoProductoTestConParametros()
        {
            // Arrange
            var p2 = new Producto(5, 550);

            var expected = "El producto 5, tiene un precio de 550�";

            // Act
            var actual = p2.InfoProducto();

            // Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void DescuentoTest()
        {
            // Arrange
            var p3 = new Producto(1, 50);

            var expected = 40;

            // Act
            var actual = p3.Descuento(p3.Precio);

            // Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void DescuentoTestConParametros()
        {
            // Arrange
            var p4 = new Producto();
            p4.Id = 4;
            p4.Precio = 10;

            var expected = 0;

            // Act
            var actual = p4.Descuento(p4.Precio);

            // Assert
            Assert.AreEqual(expected, actual);
        }
    }
}

