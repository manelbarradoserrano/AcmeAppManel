﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Acme.Biz
{

    public class Producto
    {
 
        private int idproducto;
        private double precioproducto;

   
        public int Id { get { return idproducto; } set { idproducto = value; }}
        public double Precio { get { return precioproducto; } set { precioproducto = value; }}


        public Producto()
        {
            Console.WriteLine("Producto");
        }

        public Producto(int idProducto, double precioProducto)
        {
            idproducto = idProducto;
            precioproducto = precioProducto;

            Console.WriteLine("Precio del producto: " + precioproducto);
        }


        public string InfoProducto()
        {
            string informacion = "El producto "+idproducto+", tiene un precio de "+precioproducto+"€";
            return informacion;
        }

        public double Descuento(double precioProducto)
        {
            precioProducto = precioproducto - 10;
            return precioProducto;
        }



    }
}
